<?php

$config_file = 'config/config.ini';
require 'system/vendor/autoload.php';
require 'system/htmly.php';