<article class="post type-post hentry ">
	<header class="entry-header"
	<h1 class="entry-title"><?php echo i18n('No_posts_found');?>!</h1>
	</header>
    <div class="entry-content">
    </div>
</article>